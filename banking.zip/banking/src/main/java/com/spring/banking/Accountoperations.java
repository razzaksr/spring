package com.spring.banking;

public interface Accountoperations {
public void deposite();
public void interest();
}
