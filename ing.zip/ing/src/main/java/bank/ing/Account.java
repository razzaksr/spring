package bank.ing;

public class Account 
{
	private Integer Acc_no;
	private double bal;
	public Integer getAcc_no() {
		return Acc_no;
	}
	public void setAcc_no(Integer acc_no) {
		Acc_no = acc_no;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	@Override
	public String toString() {
		return "Account [Acc_no=" + Acc_no + ", bal=" + bal + "]";
	}
	public Account(Integer acc_no, double bal) {
		Acc_no = acc_no;
		this.bal = bal;
	}
	public Account() {
	
		// TODO Auto-generated constructor stub
	}
	
}
