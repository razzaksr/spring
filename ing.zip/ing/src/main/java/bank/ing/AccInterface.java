package bank.ing;

public interface AccInterface 
{
	public void deposit();
	public void interest();
}
