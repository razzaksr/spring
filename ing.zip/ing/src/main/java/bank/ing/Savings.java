package bank.ing;


public class Savings implements AccInterface 
{
	private Account sav_acc;
	public Account getSav_acc() {
		return sav_acc;
	}

	public void setSav_acc(Account sav_acc) {
		this.sav_acc = sav_acc;
	}

	public Savings() {
		// TODO Auto-generated constructor stub
	}

	public Savings(Account sav_acc) {
		this.sav_acc = sav_acc;
	}

	public void deposit() 
	{
		int m=100;
		double	s=sav_acc.getBal();
		double  a=s+m;
		sav_acc.setBal(a);
		System.out.println(sav_acc.toString());
	}

	public void interest() {
		// TODO Auto-generated method stub
		double	s=sav_acc.getBal();
		double a=s+(s*(5.6/100));
		sav_acc.setBal(a);
		System.out.println(sav_acc.toString());
	}

}
