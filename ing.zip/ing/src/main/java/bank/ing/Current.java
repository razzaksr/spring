package bank.ing;


public class Current implements AccInterface{
	private Account cur_acc;
	
	public Current(Account cur_acc) {
		this.cur_acc = cur_acc;
	}

	public Current() {
		// TODO Auto-generated constructor stub
	}

	public Account getCur_acc() {
		return cur_acc;
	}

	public void setCur_acc(Account cur_acc) {
		this.cur_acc = cur_acc;
	}

	public void deposit() 
	{
		int m=100000;
		if(m>20000)
		{
		double	s=cur_acc.getBal();
		double  a=s+m;
		cur_acc.setBal(a);
		System.out.println(cur_acc.toString());
		}
		else
		{
			System.out.println("minimum amount to deposit is 20000");
		}
	}

	public void interest() {
		// TODO Auto-generated method stub
		double	s=cur_acc.getBal();
		double a=s+(s*(0/100));
		cur_acc.setBal(a);
		System.out.println(cur_acc.toString());
	}
}
