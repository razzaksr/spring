package bank.ing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext app=new ClassPathXmlApplicationContext("bank.xml");
		AccInterface a=(AccInterface)app.getBean("saving");
		a.deposit();
		a.interest();
		a=(AccInterface)app.getBean("current");
		a.deposit();
		a.interest();
    }
}
